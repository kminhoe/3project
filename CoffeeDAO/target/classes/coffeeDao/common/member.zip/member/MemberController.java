package coffeeDao.common.member;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

import coffeeDao.model.MemberBean;

@Controller
public class MemberController {

	@Resource(name = "joinService")
	private JoinService joinService;
	
	
	@RequestMapping(value = "/member/registerForm.da")
	public String joinSuccess(MemberBean member, BindingResult result, Model model) throws Exception {
		return "/member/registerMember";
	}
	
	@RequestMapping(value = "/member/register.da")
	public String insertSuccess(MemberBean member, BindingResult result, Model model) throws Exception {		

		joinService.insertMember(member);
		
		return "redirect:/member/loginForm.da";
	}
	
}
package coffeeDao.common.member;

import java.util.Map;

import javax.annotation.Resource;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

@Repository("memberDAO")
public class MemberDAO {

	@Resource(name = "sqlSessionTemplate")
	private SqlSessionTemplate sqlSessionTemplate;
	
	// 회원가입
	public void insertMember(Map<String, Object> map) throws Exception {
		sqlSessionTemplate.insert("member.registerMember", map);
	}	
}
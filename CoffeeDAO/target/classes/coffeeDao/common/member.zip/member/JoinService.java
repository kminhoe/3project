package coffeeDao.common.member;

import coffeeDao.model.MemberBean;

public interface JoinService {
	public void insertMember(MemberBean member) throws Exception; // 회원가입
}
